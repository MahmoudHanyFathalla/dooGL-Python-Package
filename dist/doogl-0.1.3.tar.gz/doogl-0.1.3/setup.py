from setuptools import setup, find_packages

setup(
    name="dooGL",  # The name of your package
    version="0.1.3",  # Initial version
    packages=find_packages(),  # Automatically discover all modules
    python_requires='>=3.6',  # Minimum Python version requirement
)
