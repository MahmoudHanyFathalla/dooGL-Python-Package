# Initialize core functionalities and import everything from _2d and _3d

from ._2d import *
from ._3d import *
